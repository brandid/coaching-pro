# Coaching Pro Theme Changelog

## [1.2.0] - Theme renamed to Coaching Pro - Jan 22, 2018

## [1.1.0] - Oct 3, 2017 -

Changed Customizer Header Settings to General Settings, added checkbox to that section for using the minified stylesheet. Default is not to use the minified stylesheets (home.min.css and style.min.css)
Adjusted wrap max-width for easier readability on full page widget content.
Changed max-height for the home welcome widget.
Removed sourcemap from style.css and home.css.

## [1.0.0] - July 19, 2017
* Initial Release.

## [0.9.8] - Finished moving color schemes into separate scss files, code for output of color in demo and updated output.php.
## [0.9.6] - Styling adjustments and rename several functions in theme-setup.php with coaching_pro_ prefix.

## [0.9.5] - Code Review Submission
