<?php
/**
 * Loads widgets for Coach Pro theme.
 *
 * @since 1.0
 *
 * @package Coach Pro Theme
 */

genesis_register_widget_area(
	array(
	'id'          => 'front-page-welcome',
	'name'        => __( 'Front Page Welcome Section', 'coach-pro' ),
	'description' => __( 'This is the welcome area in the header.', 'coach-pro' ),
	)
);


genesis_register_widget_area(
	array(
	'id'          => 'front-page-1a',
	'name'        => __( 'Front Page 1 - a', 'coach-pro' ),
	'description' => __( 'This is the front page 1a section.', 'coach-pro' ),
	)
);
genesis_register_widget_area(
	array(
	'id'          => 'front-page-1b',
	'name'        => __( 'Front Page 1 - b', 'coach-pro' ),
	'description' => __( 'This is the front page 1b section.', 'coach-pro' ),
	)
);
genesis_register_widget_area(
	array(
	'id'          => 'front-page-2',
	'name'        => __( 'Front Page 2', 'coach-pro' ),
	'description' => __( 'This is the front page 2 section.', 'coach-pro' ),
	)
);

genesis_register_widget_area(
	array(
	'id'          => 'front-page-3',
	'name'        => __( 'Front Page 3', 'coach-pro' ),
	'description' => __( 'This is the front page 3 section.', 'coach-pro' ),
	)
);

genesis_register_widget_area(
	array(
	'id'          => 'front-page-testimonials',
	'name'        => __( 'Front Page Testimonials', 'coach-pro' ),
	'description' => __( 'This is the front page testimonials section.', 'coach-pro' ),
	)
);


genesis_register_widget_area(
	array(
	'id'          => 'front-page-cta',
	'name'        => __( 'Front Page Call to Action', 'coach-pro' ),
	'description' => __( 'This is the call to action  section.', 'coach-pro' ),
	)
);

genesis_register_widget_area(
	array(
	'id'          => 'front-page-offer',
	'name'        => __( 'Front Page Offer', 'coach-pro' ),
	'description' => __( 'This is the front page offer section.', 'coach-pro' ),
	)
);
