# Coach Pro Theme Changelog

## [1.0.0] - TBA
* Initial Release.

## [0.9.8] - Finished moving color schemes into separate scss files, code for output of color in demo and updated output.php.
## [0.9.6] - Styling adjustments and rename several functions in theme-setup.php with coachpro_ prefix.

## [0.9.5] - Code Review Submission
