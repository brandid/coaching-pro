<?php
/**
 * Coaching Pro - One-Click Theme Setup - Demo Blog Post #1 content.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Coaching Pro
 * @author  brandiD
 */

// Output page content.
return <<<CONTENT
<!-- wp:paragraph -->
<p>This is an example of a WordPress post. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla consectetur mattis quam, eget ultricies mi efficitur ac. Sed ut imperdiet nisi. In posuere, nibh et tempor convallis, lacus metus accumsan sapien, sit amet viverra libero urna nec urna. Quisque venenatis dignissim tellus vulputate dapibus. Aliquam eu bibendum velit. Curabitur nisi risus, ornare eu lacus nec, malesuada efficitur ligula. Phasellus id dignissim mauris, vitae tempor dolor. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Curabitur dapibus eleifend vestibulum. Nullam sodales risus et dictum sagittis. Duis tortor erat, bibendum nec justo at, posuere bibendum dolor. Nullam non consectetur ex. Donec nec urna non purus bibendum feugiat ut ut quam.</p>
<!-- /wp:paragraph -->
CONTENT;
