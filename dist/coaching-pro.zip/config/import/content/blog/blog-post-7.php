<?php
/**
 * Coaching Pro - One-Click Theme Setup - Demo Blog Post #7 content.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Coaching Pro
 * @author  brandiD
 */

// Output page content.
return <<<CONTENT
<!-- wp:paragraph -->
<p>This is an example of a WordPress post. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque mollis, nunc eu molestie tempor, lectus lorem bibendum nulla, non ullamcorper tortor erat vitae risus. Nam congue rutrum sapien, non rutrum ipsum lobortis non. Aliquam sollicitudin purus in vestibulum facilisis. Phasellus cursus purus velit, eget rutrum turpis dignissim vitae. </p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Nunc ultrices quam a vestibulum rhoncus. Aenean massa tortor, fermentum at lorem eu, egestas pulvinar dolor. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec sed gravida sapien. Etiam tincidunt tortor eget magna ullamcorper rutrum.</p>
<!-- /wp:paragraph -->
CONTENT;
