<?php
/**
 * Coaching Pro - One-Click Theme Setup - Demo Testimonial #3 content.
 *
 * Visit `/wp-admin/admin.php?page=genesis-getting-started` to trigger import.
 *
 * @package Coaching Pro
 */

return array(
	'socialproofslider_testimonial_author_name'  => '<h3>Marc B.</h3>',
	'socialproofslider_testimonial_author_title' => '<p>Sarasota, FL</p>',
	'socialproofslider_testimonial_text'         => '<h4>"... already seeing results ..."</h4><p>This has been an amazing program. I\'m already seeing results. I highly recommend it.</p>',
	'_generated_page'                            => '1',
);
