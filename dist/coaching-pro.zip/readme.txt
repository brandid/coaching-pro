Coaching Pro Theme for BrandID
A WordPress Personal Branding Theme from brandiD

PURCHASE
https://thebrandidthemes.com/product/coaching-pro-personal-branding-wordpress-theme/

INSTALL
1. Make sure you have the Genesis Framework installed first.
2. Go to WordPress dashboard. Click Appearance -> Themes and then Add New, then Upload Theme.
3. Click Choose File and Upload the coaching-pro.zip
4. Activate the Coaching Pro theme.

For theme documentation, please visit https://thebrandidthemes.com/category/coaching-pro-theme/.

NOTE: Coaching Pro theme uses minified css and js files. The uncompressed files are included, but if you edit them, you'll need to recreate the minified versions.
If you want to test using uncompressed js files, add a constant COACHING_PRO_DEBUG and set to true in your wp-config.php file.

define( 'COACHING_PRO_DEBUG', true );

See changelog.md for changes.

THEME DEMO
https://coachingpro.personalbranding.thebrandid.com/

SUPPORT
Please visit https://thebrandidthemes.com/category/coaching-pro-theme/#support-form for theme support.
