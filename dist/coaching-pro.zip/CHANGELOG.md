# Coaching Pro Theme Changelog

## [2.0.0] - Dec 1, 2021
* Initial Release.
